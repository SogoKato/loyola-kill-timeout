let intervalIDLoyolaKillTimeout = setInterval(function() {document.getElementById("portaltimer").click()}, 60000)
console.log("「LOYOLAタイムアウト回避」は有効です。")
